印刷部品14個を各1個。単位mm、倍率100%、収録済みの印刷姿勢で配置します。
電子箱6枚は平らな外面をベッドへ。インサートは装置全体でM3×26個。
組立・取扱説明書と必要部材：https://github.com/dainakai/plate-lift-control
